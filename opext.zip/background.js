chrome.runtime.onInstalled.addListener(() => {
  console.log("YT Capture+ installed.");
});
